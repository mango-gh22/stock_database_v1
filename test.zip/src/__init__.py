# _*_ coding: utf-8 _*_
# File Path: E:/MyFile/stock_database_v1/src\__init__.py
# File Name: __init__
# @ File: __init__.py
# @ Author: m_mango
# @ PyCharm
# @ Date：2025/12/5 21:00
"""
desc 
"""
