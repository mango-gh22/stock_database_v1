# _*_ coding: utf-8 _*_
# File Path: E:/MyFile/stock_database_v1/src/query\__init__.py.py
# File Name: __init__.py
# @ Author: m_mango
# @ Date：2025/12/6 16:20
"""
desc 
"""
