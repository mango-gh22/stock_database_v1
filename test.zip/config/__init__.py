# _*_ coding: utf-8 _*_
# File Path: E:/MyFile/stock_database_v1/config\__init__.py
# File Name: __init__
# @ Author: mango-gh22
# @ Date：2025/12/13 18:34
"""
desc 
"""
